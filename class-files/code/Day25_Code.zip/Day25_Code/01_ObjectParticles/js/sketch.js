/*
	Objects & particles!

	Bug report: bungee, Arfek...
*/ 

var font;
var particles = [];
var characters = "Trump".split("");

function preload() {
	font = loadFont("fonts/Montserrat-Regular.ttf");
}

function setup() {
	createCanvas(windowWidth, windowHeight);

	textFont(font);
	textSize(48);
	textAlign(CENTER, CENTER);
	colorMode(HSB, 360, 100, 100, 1);

	// for (var i = 0; i < 100; i++) {
	// 	var particle = {
	// 		x: random(0, width),
	// 		y: random(0, height),
	// 		xVelocity: random(-2, 2),
	// 		yVelocity: random(-2, 2),
	// 		hue: random(240, 300),
	// 		string: random(characters),
	// 		life: random(50, 100)
	// 	};
	// 	particles.push(particle);
	// }
}

function mousePressed() {
	var dx = mouseX - pmouseX;
	var dy = mouseY - pmouseY;

	for (var i = 0; i < 50; i++) {
		var particle = {
			x: mouseX,
			y: mouseY,
			xVelocity: dx + random(-2, 2),
			yVelocity: dy + random(-2, 2),
			hue: random(240, 300),
			string: random(characters),
			life: random(50, 100)
		};
		particles.push(particle);
	}
}

function draw() {
	// background(255);

	for (var i = 0; i < particles.length; i++) {
		var particle = particles[i];

		// Update our particle based on its velocity
		particle.x += particle.xVelocity;
		particle.y += particle.yVelocity;

		// Wrap around the screen horizontally
		if (particle.x > width) {
			// Going off the right edge of the screen
			particle.x = 0;
		} else if (particle.x < 0) {
			// Going off the left edge of the screen
			particle.x = width;
		}

		// Wrap around the screen vertically
		if (particle.y > height) {
			// Going off the bottom edge of the screen
			particle.y = 0;
		} else if (particle.y < 0) {
			// Going off the top edge of the screen
			particle.y = height;
		}

		// Draw the particle
		var a = map(particle.life, 100, 0, 1, 0);
		fill(particle.hue, 100, 100, a);
		text(particle.string, particle.x, particle.y);

		// Decrease the life counter and remove the particle from 
		// the array, if necessary
		particle.life -= 1;
		if (particle.life < 0) {
			particles.splice(i, 1); // Remove the "i"th particle
			i--;
		}	
	}
}