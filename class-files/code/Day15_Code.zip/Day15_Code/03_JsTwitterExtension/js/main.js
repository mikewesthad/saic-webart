/*
	Politicizing every tweet

	Note: for this to work, you have to go to a specific URL directly. If you 
	navigation to a profile by clicking links. This won't work. We'll learn how
	to handle that later.
*/

// Test that it's working only on twitter.com:
console.log("Here's the first Clinton quote: " + clintonSentences[0]);
console.log("Here's a random number: " + randInt(0, 5));

// What element holds the text of the tweets? What selector would give you 
// access to it?

// Get all tweets on the page using querySelectorAll
var tweets = document.querySelectorAll(".tweet-text");

// Loop over all the tweets and replace their text content with a sentence from
// Hillary. (Then check out some twitter pages to see what Kanye/Bieber/Trump 
// are now tweeting. Or check out what #selfie looks like.)
for (var i = 0; i < tweets.length; i++) {
	var randomIndex = randInt(0, clintonSentences.length - 1);
	var randomSentence = clintonSentences[randomIndex];

	var tweetParagraph = tweets[i];
	tweetParagraph.textContent = randomSentence;
}