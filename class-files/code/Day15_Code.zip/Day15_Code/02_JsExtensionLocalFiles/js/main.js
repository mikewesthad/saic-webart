// Test that it's working:
console.log("Here's a random integer: " + randInt(1, 10));

// Create an array of pokemon image file names
var imageFileNames = [
	"bulbasaur.png",
	"charmander.png",
	"dratini.png",
	"eevee.png",
	"geodude.png",
	"mew.png",
	"pidgey.png",
	"pikachu.png",
	"squirtle.png",
	"vulpix.png"
];

// Get the Google banner image - what selector do we need?
var bannerImage = document.querySelector("#hplogo img");

// Pick a random file name from the array and use it to set the src of Google's
// banner image
var randomIndex = randInt(0, imageFileNames.length - 1);
var randomFile = "images/" + imageFileNames[randomIndex];
bannerImage.src = chrome.extension.getURL(randomFile);
bannerImage.style.objectFit = "scale-down";