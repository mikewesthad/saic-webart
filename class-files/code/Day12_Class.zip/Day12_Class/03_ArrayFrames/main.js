/*
	Websites As Data
	
	Create a grid of embedded websites (via iframes). Pick elements that create 
	an interesting juxtaposition. You could use: bing image searches, 
	wikipedia articles, twitter profiles, YouTube videos, etc. (Remember, some
	sites - like Google - can't be embedded via an iframe.)

	1. Create an array of urls (strings) that point to content that you want to 
	   embed.
	2. Loop over the array and do the following on each iteration of the loop:
		- Create an iframe
		- Set it's src
		- Give it a width & height
		- Add it to the body

	Challenge: Comment out your grid. Instead of displaying the iframes in grid, 
	lay them out on top of each other. This could be:
		- Random absolutely positioned elements like in 01_LoopMontage
		- A series of concentric iframes stacked on top of one another. (Hint:
		  z-index matters here.)
*/


// -- YOUR CODE ----------------------------------------------------------------

// Hot trends on google, searched via Bing
// https://www.google.com/trends/hottrends
var urls = [
	"http://www.bing.com/images/search?q=ashley+greene",
	"http://www.bing.com/images/search?q=janet+jackson",
	"http://www.bing.com/images/search?q=pansexual",
	"http://www.bing.com/images/search?q=yom+kippur",
	"http://www.bing.com/images/search?q=kayla+berg",
	"http://www.bing.com/images/search?q=american+housewife",
	"http://www.bing.com/images/search?q=national+coming+out+day",
	"http://www.bing.com/images/search?q=cam+newton",
	"http://www.bing.com/images/search?q=overwatch+halloween"
];

// Version 1:
// for (var i = 0; i < urls.length; i += 1) {
// 	var url = urls[i];
// 	var iframe = document.createElement("iframe");
// 	iframe.src = url;
// 	iframe.style.width = "33.333%";
// 	iframe.style.height = 350 + "px";
// 	document.body.appendChild(iframe);
// }

// Version 2:
for (var i = 0; i < urls.length; i += 1) {
	var url = urls[i];
	var iframe = document.createElement("iframe");
	iframe.src = url;

	iframe.className = "centered";

	iframe.style.width = (200 * i) + "px";
	iframe.style.height = (200 * i) + "px";

	iframe.style.zIndex = -i;

	iframe.style.animationDelay = (i * 2) + "s";
	iframe.style.opacity = 0.9;

	document.body.appendChild(iframe);
}