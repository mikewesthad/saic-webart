/*
	Introduction to arrays! This new type of variable lets us store a series 
	of values in one variable.
*/


// -- Creating an array --------------------------------------------------------

// Here's our first array - define an array with 6 student test scores
var scoreArray = [50, 30, 100, 84, 20, 15];

// Print out the array to the console
console.log(scoreArray);

// -- Getting values from an array ---------------------------------------------

// Display the first array element (in the console)
console.log("The first element is: " + scoreArray[0]);

// Display the last array element (in the console)
console.log("The last element is: " + scoreArray[5]);

// Display the length of the array (in the console)
console.log("The length is: " + scoreArray.length);

// Use the length of the array to get the last array element
console.log("The last element is: " + scoreArray[scoreArray.length - 1]);


// -- Adding values to an array ------------------------------------------------

// Add another score to the end of the array
scoreArray.push(89);

// Add a few more scores
scoreArray.push(25, 70, 95);

// Print out the array to the console again
console.log(scoreArray);

// -- Removing values ----------------------------------------------------------

// Remove the third and fourth element
scoreArray.splice(2, 2);
console.log(scoreArray);


// -- Looping through an array -------------------------------------------------

// Loop through the array and print the scores to the console one at a time
for (var i = 0; i < scoreArray.length; i += 1) {
	var score = scoreArray[i];
	console.log("The score is: " + score);
}

// Exercise: loop through the array and display each students score inside of an
// h1. It should look like this: 
// 		Student 1's score: 50  		(i.e. start the student numbers at 1)
// 		Student 2's score: 75
//		         ...
for (var i = 0; i < scoreArray.length; i += 1) {
	var h1 = document.createElement("h1");
	h1.textContent = "Student " + (i + 1) + "'s score is: " + scoreArray[i];
	document.body.appendChild(h1);
}

// Exercise: create an array of strings, e.g. movie quotes. Loop through them 
// and display each inside of an h1 on the page.
var movieQuotesArray = [
	"E.T. phone home.",
	"Bond. James Bond.",
	"There's no place like home.",
	"I see dead people.",
	"I'll be back."
];

for (var i = 0; i < movieQuotesArray.length; i += 1) {
	var h1 = document.createElement("h1");
	
	// This allows us to insert *just* text into our header element:
	// h1.textContent = movieQuotesArray[i];
	
	// This allows us to insert HTML into our header element:	
	h1.innerHTML = "&ldquo;" + movieQuotesArray[i] + "&rdquo;";

	h1.style.color = "rgb(50, 50, 50)";
	document.body.appendChild(h1);
}