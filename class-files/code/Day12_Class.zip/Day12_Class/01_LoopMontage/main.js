/*
	Repetition with Montage

	1. Take an image from the web (preferably a transparent one)
	2. Write a loop that puts that image on the page a large number of times 
	   in random positions.  (Hint: absolute positioning.)
	3. Add some randomness to the images created (e.g. opacity, transform, 
	   width).

	Advanced: you could also check out the CSS filter property (in Chrome)
		https://css-tricks.com/almanac/properties/f/filter/
	(If you are on Safari, you will probably need a vendor prefix: 
	"webkitFilter")
*/


// -- HELPER CODE --------------------------------------------------------------

// Helper function for generating random whole numbers between a minimum and a
// maximum value.
function randInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Helper function for generating random numbers (including numbers with 
// decimals) between a minimum and a maximum value.
function randNum(min, max) {
	return Math.random() * (max - min) + min;
}

// Schedule the page to reload. This tells the browser to refresh the page 
// 1000ms (or 1s) in the future.
// setTimeout(location.reload.bind(location), 1000);


// -- MONTAGE CODE -------------------------------------------------------------

for (var i = 0; i < 300; i++) {
	
	var randomImage = document.createElement("img");
	randomImage.src = "http://i.giphy.com/KNFADd9ZdxJGU.gif";
	
	randomImage.style.width = randInt(100, 250) + "px";

	randomImage.style.position = "absolute";
	randomImage.style.top = randInt(0, 100) + "%";
	randomImage.style.left = randInt(0, 100) + "%";

	randomImage.style.opacity = randNum(0.1, 1);
	
	// CSS
	// 	transform: translate(-50%, -50%) rotate(45deg);
	randomImage.style.transform = "translate(-50%, -50%) rotate(" + randInt(-20, 20) + "deg)";
	
	// CSS
	// 	filter: hue-rotate(45deg);
	// 	-webkit-filter: hue-rotate(45deg);
	randomImage.style.filter = "hue-rotate(" + randInt(0, 100) + "deg)";
	randomImage.style.webkitFilter = "hue-rotate(" + randInt(0, 100) + "deg)";
	
	document.body.appendChild(randomImage); 
}

// Add one more centered image
var randomImage = document.createElement("img");
randomImage.src = "http://i.giphy.com/KNFADd9ZdxJGU.gif";
randomImage.style.position = "absolute";
randomImage.style.width = "700px";
randomImage.style.opacity = 0.95;
randomImage.style.top = "50%";
randomImage.style.left = "50%";
randomImage.style.transform = "translate(-50%, -50%) rotate(" + randInt(-20, 20) + "deg)";
randomImage.style.filter = "hue-rotate(" + randInt(0, 100) + "deg)";
document.body.appendChild(randomImage); 
