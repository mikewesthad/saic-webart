/*
	Loop through all the emojis and put them on the page in img elements. Give 
	them 10% width.

	Images range from emoji-images/1.png to emoji-images/1832.png

	Helpful code:

		document.createElement(...)
		document.body

	Emoji source: http://emojione.com/ 
*/


for (var i = 1; i < 1832; i += 1) {
	var emojiImg = document.createElement("img");
	emojiImg.src = "emoji-images/" + i + ".png";
	emojiImg.style.width = "10%";
	document.body.appendChild(emojiImg);
}