/*
	Writing to the page - document.write(...)

	Emoji source: http://emojione.com/ 
*/


// -- HELPER CODE --------------------------------------------------------------

// Helper function for generating random whole numbers between a minimum and a
// maximum value.
function randInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Helper function for generating random numbers (including numbers with 
// decimals) between a minimum and a maximum value.
function randNum(min, max) {
	return Math.random() * (max - min) + min;
}

// Schedule the page to reload. This tells the browser to refresh the page 
// 1000ms (or 1s) in the future.
// setTimeout(location.reload.bind(location), 2000);


// -- WARMUP -------------------------------------------------------------------

// Write an h1 to the page with document.write(...)
document.write("<h1>Hello again.</h1>");

// Write an h1 to the page with a random letter-spacing
// 	<h1 style='letter-spacing: 30px'>YESSSSSSSSSS</h1>
var randLetterSpacing = randNum(1, 200);
document.write("<h1 style='letter-spacing: " + randLetterSpacing +
	"px'>YESSSSSSSSSS</h1>");

// Write a random image to the page (using emoji-images/)
// 	<img src='emoji-images/1.png'>
// var randImageName = randInt(0, 1834);
// document.write("<img src='emoji-images/" + randImageName + ".png'>")


// -- APPLYING STYLE -----------------------------------------------------------


var randImageName = randInt(0, 1834);
document.write("<img class='emoji-image' src='emoji-images/" + 
	randImageName + ".png'>");

var randImageName = randInt(0, 1834);
document.write("<img style='border-color: red' class='emoji-image' src='emoji-images/" + 
	randImageName + ".png'>");