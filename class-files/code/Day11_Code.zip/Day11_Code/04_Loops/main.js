/*
	Repetition

	(-(-_(-_-)_-)-)
*/

// -- FIRST LOOPS --------------------------------------------------------------

// Your first loop - count from 0 to 9
for (var i = 0; i < 10; i = i + 1) {
	console.log("The count is: " + i);
}

// Your second loop - count by 2, from 4 to 20
for (var i = 4; i <= 20; i = i + 2) {
	var h1 = document.createElement("h1");
	h1.textContent = i;
	document.body.appendChild(h1);
}

// Danger zone - infinite loops
// for (var i = 0; i >= 0; i = i + 1) {
// 	console.log("The count is: " + i);
// }

// -- EXERCISES ----------------------------------------------------------------

// Count by 5s, from 10 through 100
for (var i = 10; i <= 100; i = i + 5) {
	var h1 = document.createElement("h1");
	h1.textContent = i;
	h1.style.color = "crimson";
	document.body.appendChild(h1);
}

// Count down from 10 to 1
for (var i = 10; i > 0; i = i - 1) {
	var h1 = document.createElement("h1");
	h1.textContent = i;
	h1.style.color = "deepskyblue";
	document.body.appendChild(h1);
}

// Count from 10 to 50 and use the value of i to set the font-size of each h1
for (var i = 10; i <= 50; i = i + 1) {
	var h1 = document.createElement("h1");
	h1.textContent = i;
	h1.style.fontSize = (10 * i) + "px";
	document.body.appendChild(h1);
}