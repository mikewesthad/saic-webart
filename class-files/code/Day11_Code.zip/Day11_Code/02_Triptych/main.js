/*
	Generative Triptych

	1. Link this file to your index.html page.
	2. As a test of your knowledge, make a triptych (or any other number "tych")
	   drawing from random emoji images. Uncomment the refresh code to turn
	   your page into a generative composition.
  	3. Now make a triptych from your own collection of images. Remember that
       the image files will need to be named sequentially and need to have the
       same file extension. (You may want to use "object-fit" here.)

	Advanced extensions:

	- Apply an animation (or transition) to your images
    - You can control the image files used for each img element by organizing
      your files. If you have a setup with three directories:
	      images1/
	      images2/
	      images3/
	  Then you can set each img element to pull from a separate directory.
	- Apply some random styling to your elements (e.g. width, height, position,
	  etc.)

	Advanced tip, if you have a bunch of files that you need to rename
	sequentially and you are comfortable with terminal, this may help:
		ls | cat -n | while read n f; do mv "$f" "$n.png"; done
*/


// -- HELPER CODE --------------------------------------------------------------

// Helper function for generating random whole numbers between a minimum and a
// maximum value.
function randInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Helper function for generating random numbers (including numbers with 
// decimals) between a minimum and a maximum value.
function randNum(min, max) {
	return Math.random() * (max - min) + min;
}

// Schedule the page to reload. This tells the browser to refresh the page
// 1000ms (or 1s) in the future.
setTimeout(location.reload.bind(location), 1000);


// -- YOUR CODE ----------------------------------------------------------------

// Simple demo:
document.write("<img class='triptych' src=emoji-images/" + randInt(1, 1834) + ".png>");
document.write("<img class='triptych' src=emoji-images/" + randInt(1, 1834) + ".png>");
document.write("<img class='triptych' src=emoji-images/" + randInt(1, 1834) + ".png>");