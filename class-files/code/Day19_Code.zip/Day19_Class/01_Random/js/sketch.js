/*
	Mouse + Random
	
	Steps:
	1. Create a canvas
	2. Draw a background (in setup)
	3. Draw an ellipse on the screen where the mouse is
	4. Take a look at the random(...) function in p5. Use it to give the ellipse
	   some random fill or stroke color. Reference: 
	   http://p5js.org/reference/#/p5/random
	5. Try randomizing some other aspects of the drawing
	6. When the user right clicks, clear the screen

*/ 

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);
}

function draw() {
	if (mouseIsPressed) {
		if (mouseButton === LEFT) {
			var radius = random(40, 100);

			// Random grayscale
			var gray = random(50, 255);
			fill(gray);

			// Random RGB
			// fill(random(0, 75), 0, random(100, 255));

			noStroke();

			ellipse(mouseX, mouseY, radius, radius);
		} else if (mouseButton === RIGHT) {
			// Erasing the screen
			background(0);
		}
	}
}
