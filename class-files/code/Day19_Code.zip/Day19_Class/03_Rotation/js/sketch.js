/*
	Loading Images

	Since this sketch loads an image file, it *needs* to be viewed through a 
	local server.

	New p5 variables and functions:
		push(...)
		pop(...)
		translate(...)
		scale(...)
		rotate(...)
*/ 

var img;
var rotation = 0;

function preload() {
	img = loadImage("images/catball.png");
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	angleMode(DEGREES);
}

function draw() {

	push(); // Saves the current style and transformations
		tint(255, 125);
		imageMode(CENTER);			// Draw from the center
		translate(mouseX, mouseY); 	// Move to where we want to draw
		rotate(rotation);			// Rotate in place
		scale(1.5);					// Scale in place
		image(img, 0, 0);			// Draw at (0, 0)
	pop(); // Restores the previous style and transformations

	rotation += 25;

	// Alternatively, the same strategy could be applied to shapes:
	// push(); // Saves the current style and transformations
	// 	fill(0, 0, 0);
	// 	stroke(100, 0, 255);
	// 	rectMode(CENTER);			// Draw from the center
	// 	translate(mouseX, mouseY); 	// Move to where we want to draw
	// 	rotate(rotation);			// Rotate in place
	// 	scale(3);					// Scale in place
	// 	rect(0, 0, 100, 100);		// Draw at (0, 0)
	// pop(); // Restores the previous style and transformations

}