/*
	Loading Images

	Since this sketch loads an image file, it *needs* to be viewed through a 
	local server.

	New p5 variables and functions:
		preload(...)
		loadImage(...)
		tint(...)
		imageMode(...)
		image(...)
*/ 

// Global variable to store the image
var img;

function preload() {
	img = loadImage("images/catball.png");
}

function setup() {
	createCanvas(windowWidth, windowHeight);
}

function draw() {
	background(255, 10);

	imageMode(CENTER); // Can be CENTER, CORNER, CORNERS

	// Apply a colored tint
	tint(100, 0, random(50, 255));

	// Apply a white tint with opacity
	// tint(255, 255, 255, 100); 
	
	// Randomly scale the image while preserving the aspect ratio
	var randomScale = random(0, 3);
	image(img, mouseX, mouseY, randomScale * img.width, randomScale * img.height);
}