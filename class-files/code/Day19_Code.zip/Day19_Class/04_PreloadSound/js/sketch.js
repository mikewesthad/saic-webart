/*
	Music visualizer
	
	Since this sketch loads a sound file, it *needs* to be viewed through a 
	local server. For playing a track, we will need to:

	1. Grab an mp3 track (soundcloud is a good place to find free downloads)
	2. Save it to the "audio/" folder
	3. Include the p5.js sound library in index.html
	4. Load the sound in a preload() function
	5. Play the sound in the setup() function
	6. Open index.html in SublimeServer

	Note: each browser supports a different set of sound file format.  To ensure
	compatibility, you need your track in multiple formats.  Check out this p5
	example: http://p5js.org/examples/sound-soundformats.html

	New p5 variables and functions:
		preload()
		width
		height
		map(...)

	New p5.sound variables and functions:
		loadSound(...)
		SoundFile.play()
		SoundFile.getLevel(...)
		SoundFile.rate(...)
		SoundFile.jump(...)
		p5.Amplitude()
		Amplitude.getLevel()
*/ 

var musicTrack;
var amplitude;

function preload() {
	musicTrack = loadSound("audio/baths-animals.mp3")
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);

	musicTrack.play();
	// We can skip ahead to a specific timestamp (in seconds)
	musicTrack.jump(30);
	// Get the amplitude of all p5 sounds
	amplitude = new p5.Amplitude();
}

function draw() {
	background(0, 10); // Slowly clear the screen

	// Styling for the ellipse
	fill(255, 255, 255);
	stroke(255, 200, 0);
	strokeWeight(25);

	// Get the current volume (a number between 0 and 1)
	var level = amplitude.getLevel();
	var size = map(level, 0, 1, 100, 1000);
	ellipse(width / 2, height / 2, size, size);

	var newRate = map(mouseX, 0, width, 0.01, 5);
	musicTrack.rate(newRate);
}
