/*
	GIF Translation

	Giphy Documentation: https://github.com/Giphy/GiphyAPI
	Translate Documentation: https://github.com/Giphy/GiphyAPI#translate-endpoint
*/ 

// Checkout the HTML setup
var input;
var imageContainer;

function setup() {
	// Screw the canvas
	noCanvas();

	// Pull the DOM elements out of the page
	input = select("#translation-input");
	imageContainer = select("#image-translation");
	input.elt.focus();
}

function keyPressed() {
	if (keyCode === ENTER) {
		console.log("You pressed enter!");
		console.log("You want to search for: " + input.value());

		var phrase = input.value();
		var url = "http://api.giphy.com/v1/gifs/translate?" +
			"s=" + phrase + 
			"&api_key=dc6zaTOxFJmzC";
		loadJSON(url, onGiphyLoaded, onGiphyFailed);
	}
}

function onGiphyLoaded(json) {
	console.log(json);
	var src = json.data.images.fixed_height.url;
	var img = createImg(src);
	img.parent(imageContainer);
}

function onGiphyFailed(response) {
	// This will run if p5 had trouble talking to the API
	// over the network (mistyped URLs, network disconnections)
	console.log("Error!");
	console.log(response);
}