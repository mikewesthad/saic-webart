/*
	Words on Words

	Sign up: https://www.wordnik.com/signup
	Request API key: http://developer.wordnik.com/

	If you don't get an email back, check your account settings 
	(https://www.wordnik.com/users/edit) and look towards the bottom of the 
	page.
	
	Random word documentation:
		http://developer.wordnik.com/docs.html#!/words/getRandomWord_get_4
*/ 

var nounButton;
var advButton;
var verbButton;

// My API key - get your own! :)
var wordnikApiKey = "7fa3393edc93049a4101001a33b0dfbfa20c3d58b80084ae6";

function setup() {
	noCanvas(); // No need for the canvas

	// Simple styling - this could also be achieved with CSS
	document.body.style.textAlign = "center";
	document.body.style.marginTop = "100px";

	nounButton = createButton("[proper noun]");
	nounButton.mousePressed(getNewNoun);
	nounButton.style("font-size", "40px");

	advButton = createButton("[adverb]");
	advButton.style("font-size", "40px");
	advButton.mousePressed(getNewAdverb);

	verbButton = createButton("[verb]");
	verbButton.style("font-size", "40px");
	verbButton.mousePressed(getNewVerb);
}

function getNewNoun() {
	var url = "https://api.wordnik.com/v4/words.json/randomWord?" +
		"&includePartOfSpeech=proper-noun" +
		"&api_key=" + wordnikApiKey;

	// Disable the button when the loadJSON starts. Disabled buttons can't be
	// clicked (e.g. getNewNoun can't be triggered while the button is
	// disabled.)
	nounButton.attribute("disabled", true);

	loadJSON(url, function (jsonData) {
		// .html sets the innerHtml of the button
		nounButton.html(jsonData.word);

		// Renable the button now that we've got a new word
		nounButton.removeAttribute("disabled");
	});
}

function getNewAdverb() {
	var url = "https://api.wordnik.com/v4/words.json/randomWord?" +
		"&includePartOfSpeech=adverb" +
		"&api_key=" + wordnikApiKey;

	advButton.attribute("disabled", true);

	loadJSON(url, function (jsonData) {
		advButton.removeAttribute("disabled");
		advButton.html(jsonData.word);
	});
}

function getNewVerb() {
	var url = "https://api.wordnik.com/v4/words.json/randomWord?" +
		"&includePartOfSpeech=verb" +
		"&api_key=" + wordnikApiKey;
		
	verbButton.attribute("disabled", true);

	loadJSON(url, function (jsonData) {
		verbButton.removeAttribute("disabled");
		verbButton.html(jsonData.word);
	});
}