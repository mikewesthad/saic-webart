/*
	Drones and JSONP
	
	Drone API documentation: http://dronestre.am
	Google maps documentation: https://developers.google.com/maps/documentation/javascript/tutorial
	Google Maps API Key: https://developers.google.com/maps/documentation/javascript/get-api-key#key

	We didn't get to talk about this example in class, so check out the 
	documenation links above! Google maps has a nice guide to their API.
*/ 

var droneStrikes;
var googleMap;
var strikeIndex = 0;
var myVoice = new p5.Speech(); // new P5.Speech object

function setup() {
	// Note: we didn't get to talk about this in class! Some APIs don't allow
	// "cross-origin resource sharing" (CORS). That means that you can't access
	// them directly from your website without getting the error. The workaround
	// involves telling loadJSON to use "jsonp". This is a different way of 
	// loading data from an API, even though it is functionally the same to us.
	
	// Ask for the drone dataset and call onDroneData when it is loaded.
	loadJSON("http://api.dronestre.am/data", onDroneData, "jsonp");
}

function initMap() {
	// This is called by the Google Maps API script. Check out index.html to see
	// the script tag.
	// Put the map in the div#google-map that is already on the page.
	var mapDiv = document.getElementById("google-map");
	googleMap = new google.maps.Map(mapDiv, {
		// Starting location (no particular reason for this location)
		center: {lat: -34.397, lng: 150.644},
		// What level of zoom
		zoom: 20,
		// The type of map
		mapTypeId: "satellite"
	});
}

function onDroneData(json) {
	// This is called when the drone data is loaded
	console.log(json);

	// Pull out the array of strike data
	droneStrikes = json.strike;
	
	// Loop over the strikes and add a marker to the Google map at each location
	for (var i = 0; i < droneStrikes.length; i++) {
		var latitude = Number(droneStrikes[i].lat);
		var longitude = Number(droneStrikes[i].lon);
		var marker = new google.maps.Marker({
			position: {lat: latitude, lng: longitude},
			map: googleMap
 		});
	}

	// Zoom in on a drone strike and speak it's location
	nextStrike();
}

function nextStrike() {
	// This function "loops" through the drone strike array - zooming in on a
	// location, speaking it's name, waiting 2 seconds, and then repeating
	
	// Center the map
	var latitude = Number(droneStrikes[strikeIndex].lat);
	var longitude = Number(droneStrikes[strikeIndex].lon);
	googleMap.setCenter({
		lat: latitude, 
		lng: longitude
	});

	// Speak the location
	myVoice.speak(droneStrikes[strikeIndex].location);

	// Get ready for the next iteration
	strikeIndex++;
	if (strikeIndex >= droneStrikes.length) {
		strikeIndex = 0;
	}
	setTimeout(nextStrike, 2000);
}