/*
	GIFS!

	Documentation: https://github.com/Giphy/GiphyAPI
	Search Documentation: https://github.com/Giphy/GiphyAPI#search-endpoint
*/ 

var giphyJson;

function preload() {
	var url = "http://api.giphy.com/v1/gifs/search?"
		+ "q=mondays"
		+ "&limit=100"
		+ "&api_key=dc6zaTOxFJmzC";
	giphyJson = loadJSON(url);
}

function setup() {
	// Turn off the canvas for the sketch
	noCanvas();

	// console.log(giphyJson.data[0].images.fixed_height.url);
	// var src = giphyJson.data[0].images.fixed_height.url;
	// createImg(src);

	// Loop through and put all of the search results on the page
	var results = giphyJson.data;
	for (var i = 0; i < results.length; i++) {
		var src = results[i].images.fixed_height.url;
		createImg(src);
	}
}