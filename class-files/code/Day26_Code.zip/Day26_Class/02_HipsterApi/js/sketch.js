/*
	Hipster Api!

	API documentation: http://hipsterjesus.com

	Install a JSON formatter extension for your browser:
	    - Chrome: https://chrome.google.com/webstore/detail/json-formatter/bcjindcccaagfpapjjmafapmmgkkhgoa?hl=en
	    - Firefox: https://addons.mozilla.org/en-us/firefox/addon/jsonview/
	    - Safari: https://github.com/rfletcher/safari-json-formatter

	p5.Speech documentation: http://ability.nyu.edu/p5.js-speech/
*/ 

var hipsterData;
var hipsterWordsArray;
var hipsterWordsIndex = 0;
var myVoice = new p5.Speech(); // Speech synthesis object

function preload() {
	// Parts of the API call:
	// 	endpoint ? parameter=value & parameter=value ...
	var url = "http://hipsterjesus.com/api/?"
		+ "paras=1"
		+ "&type=hipster-centric"
		+ "&html=false";
	hipsterData = loadJSON(url);
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(255);

	// textSize(25);
	// text(hipsterData.text, 50, 50, 600, 600);
	// myVoice.speak(hipsterData.text);

	hipsterWordsArray = hipsterData.text.split(" ");
	// Note: we needed to clean up the array and remove any "empty"
	// words, so that the speech synthesis didn't break on macs
	var cleanedArray = [];
	for (var i = 0; i < hipsterWordsArray.length; i++) {
		var trimmedWord = hipsterWordsArray[i].trim(); 
		if (trimmedWord !== "") {
			cleanedArray.push(trimmedWord);
		}
	}
	hipsterWordsArray = cleanedArray;

	// console.log(hipsterWordsArray);
	myVoice.speak("Hipster");
	myVoice.onEnd = nextWord;
}

function nextWord() {
	var word = hipsterWordsArray[hipsterWordsIndex];

	var pitchValue = map(mouseX, 0, width, 0.01, 2);
	myVoice.setPitch(pitchValue);

	var rateValue = map(mouseY, 0, height, 0.1, 2);
	myVoice.setRate(rateValue);

	myVoice.speak(word);

	var rx = random(0, width);
	var ry = random(0, height);
	textAlign(CENTER, CENTER);
	textSize(80);
	text(word, rx, ry);

	hipsterWordsIndex += 1;
	if (hipsterWordsIndex >= hipsterWordsArray.length) {
		hipsterWordsIndex = 0;
	}
}

function draw() {

}