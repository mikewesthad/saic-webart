/*
	Pixels!
*/ 

var img;
var stepSize = 10;
var imageScale = 2.5;

function preload() {
	img = loadImage("images/hipster.jpg");
}

function setup() {
	createCanvas(imageScale * img.width, imageScale * img.height);

	// Load the pixels so that we can access them
	img.loadPixels();

	// Hack for high DPI screens (e.g. retina screens)
	pixelDensity(1);
}

function draw() {
	background(0);

	// This allows us to visualize how stepSize affects the loop below. Leave
	// this disabled when you have figured out what value of stepSize you want
	// to use
	// stepSize = round(map(mouseX, 0, width, 5, 20));
	
	for (var x = 0; x < img.width; x += stepSize) {
		for (var y = 0; y < img.height; y += stepSize) {

			// Convert from (x, y) to the flattened pixels array
			var i = 4 * (y * img.width + x);

			// Extract the color for the current pixel at (x, y)
			var r = img.pixels[i];
			var g = img.pixels[i + 1];
			var b = img.pixels[i + 2];
			var a = img.pixels[i + 3];

			// Calculate the brightness from the (r, g, b, a) of the pixel
			var pixelBrightness = brightness([r, g, b, a]);
			var size = map(pixelBrightness, 0, 100, 0, 2 * stepSize);

			// Scale up the location where we are about to draw the ellipse
			var scaledX = imageScale * x;
			var scaledY = imageScale * y;

			// Use the distance between the mouse and the soon-to-be ellipse in
			// order to control the size of the ellipse
			var distance = dist(scaledX, scaledY, mouseX, mouseY);
			distance = constrain(distance, 0, 300);
			var size = map(distance, 0, 300, 45, 2);

			// Draw the ellipse
			fill(r, g, b, a);
			noStroke();
			ellipse(scaledX, scaledY, size, size);
		}
	}
}