/*
	Sliders!
*/ 

var img;
var widthSlider;
var heightSlider;
var rotationSlider;

function preload() {
	img = loadImage("images/catball.png");
}

function setup() {
	createCanvas(600, 600);

	widthSlider = createSlider(0, 1000, 600);
	widthSlider.position(620, 20);
	widthSlider.size(300, 50);

	heightSlider = createSlider(0, 1000, 600);
	heightSlider.position(620, 100);
	heightSlider.size(300, 50);

	rotationSlider = createSlider(0, 360, 0);
	rotationSlider.position(620, 180);
	rotationSlider.size(300, 50);

	angleMode(DEGREES);
}

function draw() {
	background(0);

	push();
		translate(width / 2, height / 2);
		rotate(rotationSlider.value());
		imageMode(CENTER);
		image(img, 0, 0, widthSlider.value(), heightSlider.value());
	pop();
}