/*
	Loading a font

	Since this sketch loads a font, it *needs* to be viewed through a local 
	server.

	New p5 variables and functions:
		loadFont(...)
		textFont(...)
		textSize(...)
		text(...)
*/ 

var myFont;
var currentWord = "";
var rotation = 0;

function preload() {
	myFont = loadFont("fonts/AlfaSlabOne-Regular.ttf");
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);

	textFont(myFont);
	textSize(100);

	angleMode(DEGREES);
}

function draw() {
	background(0, 10);

	fill(255);
	strokeWeight(20);
	textAlign(CENTER, CENTER);

	push();
		translate(mouseX, mouseY);
		rotate(rotation);
		text(currentWord, 0, 0);
	pop();
}

function mousePressed() {
	stroke(random(100, 255), 0, random(100, 255));
}

function mouseWheel(event) {
	rotation += event.delta;
}

function keyTyped() {
	currentWord += key;
}

function keyPressed() {
	if (keyCode === BACKSPACE) {
		currentWord = currentWord.slice(0, -1);
	}
}