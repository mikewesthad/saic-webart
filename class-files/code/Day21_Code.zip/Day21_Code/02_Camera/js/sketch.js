/*
	We can get the web camera through p5.js. It's actually a video element under
	the hood, so include p5.dom.min.js!

	Again, the tutorial on video in p5 is a good reference: 
		http://creative-coding.decontextualize.com/video/
*/

var capture;
var stepSize = 10;

function setup() {
	createCanvas(640, 480);

	capture = createCapture(VIDEO);
	capture.hide();

	pixelDensity(1); // Fix for high DPI screens
}

function draw() {
	background(0);

	// Drawing and filtering the canvas
	// image(capture, 0, 0);
	// filter(THRESHOLD, 0.5);
	// filter(POSTERIZE, 2);
	
	// Manipulating the pixels
	capture.loadPixels();
	if (capture.pixels.length === 0) {
		// Stop running the draw code until we have pixels from the capture
		return;
	}

	for (var px = 0; px < capture.width; px += stepSize) {
		for (var py = 0; py < capture.height; py += stepSize) {
			var i = 4 * (py * capture.width + px);
			var r = capture.pixels[i];
			var g = capture.pixels[i + 1];
			var b = capture.pixels[i + 2];
			var a = capture.pixels[i + 3];

			fill(r, g, b, 200);
			noStroke();

			var pixelSaturation = saturation([r, g, b, a]);
			var pixelBrightness = brightness([r, g, b, a]);
			var pixelHue = hue([r, g, b, a]);

			var rectWidth = map(pixelSaturation, 0, 100, 0, 10 * stepSize);
			var rectHeight = map(pixelBrightness, 0, 100, 0, 10 * stepSize);
			// rect(px, py, rectWidth, rectHeight);

			push();
				translate(px, py);
				angleMode(DEGREES);
				rotate(pixelHue);
				rectMode(CENTER);
				rect(0, 0, rectWidth, rectHeight);
			pop();

		}
	}

}