/*
	DOM Modification - Getting elements and modifying them

	Let's destroy a website.
*/


// -- GETTING ELEMENTS ---------------------------------------------------------

// Get something from the DOM using an ID and store it in a variable
var header = document.getElementById("header");

// Print out the element - notice anything special when you hover over the 
// output in the console?
console.log(header);

// Modifying the element
header.style.padding = "50px";
header.style.width = "60px";
header.style.fontFamily = "cursive";
header.style.backgroundColor = "red";
header.style.color = "black";
header.textContent = "hai there";

// What happens if you make a typo?

// The body element is accessible directly via: document.body
var body = document.body;
body.style.backgroundColor = "blue";

// What happens if you misplace your script in index.html?


// -- TRAVERSING THE DOM -------------------------------------------------------

// Start at the header and get to the img element
var contentDiv = header.nextElementSibling;
var figure = contentDiv.firstElementChild;
var catImage = figure.firstElementChild;
console.log(catImage);

// Change the image from attack.gif to meow.gif
catImage.src = "images/meow.gif";

// Get the figcaption and change it's text content
var caption = catImage.nextElementSibling;
caption.textContent = "pay attention to me";

// What if you ask for a child when one doesn't exist?
console.log(caption.firstElementChild);

// Similar process for going back up
console.log(caption.parentElement);
console.log(caption.parentElement.parentElement);