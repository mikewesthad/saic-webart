/*
	Warmup
*/


// Source: https://github.com/dariusk/corpora/blob/master/data/words/rhymeless_words.json
var nonRhymingWords = ["adzed","airt","aitch","alb","amongst","angel","angry","angst","angsts","anxious","arugula","beige","bilge","blitzed","borscht","breadth","bronzed","bulb","cairn","chaos","chimney","circle","circus","cleansed","coif","comment","coolth","corpsed","cusp","delft","depth","doth","eighth","elbow","else","empty","engine","eth","false","fiends","fifth","film","filmed","flange","foible","fourths","foyer","fugue","glimpsed","gouge","grilse","gulf","heighth","hundred","husband","iron","karsts","kiln","kilned","kirsch","liquid","loge","luggage","midst","midsts","monster","month","mulcts","music","neutron","ninth","nothing","oblige","olive","oomph","opus","orange","penguin","pierced","pint","plankton","plinth","polka","problem","prompts","purple","quaich","rhythm","rouged","sanction","sandwich","scarce","sculpts","secret","silver","siren","sixth","something","sowthed","spoilt","stilb","toilet","traipsed","tufts","twelfth","unbeknowns","vuln","waltzed","warmth","whilst","width","wolf","wolve","woman","worlds","wounds","yogh","yoicks","yttrium","zigzag"];

// Log the 23rd element in the array
console.log(nonRhymingWords[22]);

// Log the number of words in nonRhymingWords
console.log(nonRhymingWords.length);

// Log the last element in the array
console.log(nonRhymingWords[nonRhymingWords.length - 1]);

// Loop through the array and print every *other* word out to the page in an h1
for (var i = 0; i < nonRhymingWords.length - 1; i += 2) {
	var h1 = document.createElement("h1");
	h1.textContent = nonRhymingWords[i];
	h1.style.textAlign = "center";
	document.body.appendChild(h1);
}