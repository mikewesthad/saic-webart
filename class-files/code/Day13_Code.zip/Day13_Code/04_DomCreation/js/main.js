/* 
	Creating new elements and adding them to the DOM

	We are going to walk through the process of adding a paragraph and a list to
	an existing div (using the DOM manipulation method).
	
	Here is the general process for adding an element:
		1. Get your new element ready
			- Create your element
			- If your element needs text, add text to it
			- If your element has children (like a list), add the children to 
			  the element
		2. Add your element to the DOM using appendChild
			- Find the existing element you want to be the *parent* of your new 
			  element
			- Add your new element as a child of that parent
*/

// -- ADDING A PARAGRAPH -------------------------------------------------------

// Create a paragraph element give it some text and add it as a child of the 
// content div.  For the text, you can use a paragraph from one of the ipsum
// generators.
var paragraph = document.createElement("p");
paragraph.textContent = "Hodor, hodor - hodor - hodor - hodor hodor! Hodor hodor - HODOR hodor, hodor hodor - hodor. Hodor hodor - hodor... Hodor hodor hodor? Hodor, hodor; hodor hodor. Hodor. Hodor hodor; hodor hodor hodor - hodor. Hodor hodor HODOR! Hodor HODOR hodor, hodor hodor... Hodor hodor HODOR hodor, hodor hodor? Hodor. Hodor hodor, hodor. Hodor hodor - HODOR hodor, hodor hodor hodor! Hodor. Hodor hodor hodor; hodor hodor, hodor, hodor hodor. Hodor, hodor hodor hodor hodor, hodor, hodor hodor.";
var contentDiv = document.querySelector("#content");
contentDiv.appendChild(paragraph);

// -- ADDING A LIST ------------------------------------------------------------

// Create an "top three" ordered list (topic of your choosing). Add that list 
// as a child of the list-container div.

// Create an unordered list element (e.g. ol)
var orderedList = document.createElement("ol");

// Create three list items (e.g. li) and give each one some text
var item1 = document.createElement("li");
item1.textContent = "Hodor, hodor";
var item2 = document.createElement("li");
item2.textContent = "Hodor!";
var item3 = document.createElement("li");
item3.textContent = "Hodor, hodor, HODOR.";

// Append the list items to the ordered list
orderedList.appendChild(item1);
orderedList.appendChild(item2);
orderedList.appendChild(item3);
console.log(orderedList);

// Add the list to the list-container div
var listContainer = document.querySelector("#list-container");
listContainer.appendChild(orderedList);