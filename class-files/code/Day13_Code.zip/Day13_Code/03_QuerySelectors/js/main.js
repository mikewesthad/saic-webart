/*
	Query Selectors: The most powerful of selectors.

	querySelector(...)
		https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
	querySelectorAll(...)
		https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelectorAll
*/

// Using querySelector(...), change the title to be "Slooooooow"
var title = document.querySelector(".title");
title.textContent = "Sloooooooow";

// Using querySelectorAll(...), add a border to all the images 
var images = document.querySelectorAll("#gallery img");
for (var i = 0; i < images.length; i++) {
	images[i].style.border = "10px solid black";
}

// Exercise: using querySelector(...), change the width of the wrap div to be 
// 1000px
var wrapDiv = document.querySelector("#wrap");
wrapDiv.style.width = "1000px";

// Exercise: using querySelector(...), add a border to the first image
var firstImage = document.querySelector(".highlighted");
firstImage.style.border = "10px dotted red";

// Exercise: using querySelectorAll(...), give all the images with a class of 
// highlighted a different styling (for example, a different border styling)
var highlightedImages = document.querySelectorAll(".highlighted");
for (var i = 0; i < highlightedImages.length; i++) {
	highlightedImages[i].style.border = "10px solid white";
}