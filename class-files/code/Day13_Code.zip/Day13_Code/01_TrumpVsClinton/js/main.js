/*
	TRUMP v. CLINTON
	
	Loop some number of times and each iteration:
		- Pick a random sentence from Trump or Clinton
		- Put it on the page in a div
		- Place the div in a random place on the page
	
	Animation extension:
		- Check out the fade animation
		- Apply the fade class to get a fade animation
		- Use "i" to set the animation delay so that each sentence shows up one
		  after another (instead of all of them fading in together)

	Versus extension:
		- Use both clinton and trump sentences, but differentiate them by style
		  (e.g. red vs blue color, font-style, font-family, etc.)
		- Use "i" to increase the font-size so that each progressive sentence
		  is larger than the last 
*/

// Getting a random element from an array
var randomTrumpIndex = randInt(0, trumpSentences.length - 1);
var randomTrumpSentence = trumpSentences[randomTrumpIndex];
console.log(randomTrumpSentence);


// Loop
for (var i = 0; i < 100; i += 1) {

	// Trump
	var randTrumpIndex = randInt(0, trumpSentences.length - 1);
	var randTrumpSentence = trumpSentences[randTrumpIndex];

	var randTrumpDiv = document.createElement("div");
	randTrumpDiv.style.position = "absolute";
	randTrumpDiv.style.left = randNum(20, 80) + "vw";
	randTrumpDiv.style.top = randNum(20, 80) + "vh";
	randTrumpDiv.style.transform = "translate(-50%, -50%) rotate(" + randInt(-20, 20) + "deg)";
	randTrumpDiv.textContent = randTrumpSentence;
	randTrumpDiv.className = "trump-sentence fade";
	randTrumpDiv.style.animationDelay = (5 * i) + "s";
	randTrumpDiv.style.fontSize = (20 + (2 * i)) + "px";
	document.body.appendChild(randTrumpDiv);

	// Clinton
	var randClintonIndex = randInt(0, clintonSentences.length - 1);
	var randClintonSentence = clintonSentences[randTrumpIndex];

	var randClintonDiv = document.createElement("div");
	randClintonDiv.style.position = "absolute";
	randClintonDiv.style.left = randNum(20, 80) + "vw";
	randClintonDiv.style.top = randNum(20, 80) + "vh";
	randClintonDiv.style.transform = "translate(-50%, -50%) rotate(" + randInt(-20, 20) + "deg)";
	randClintonDiv.textContent = randClintonSentence;
	randClintonDiv.className = "clinton-sentence fade";
	randClintonDiv.style.fontSize = (20 + (2 * i)) + "px";
	randClintonDiv.style.animationDelay = ((5 * i) + 2) + "s";
	document.body.appendChild(randClintonDiv);

}
