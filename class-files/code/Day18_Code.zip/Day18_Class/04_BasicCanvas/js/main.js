/* 
	"Raw" Canvas Demo

	We are going to do a simple demo using the basic canvas commands. We do this
	so that we will understand what p5 is doing for us under the hood.
*/

// Add a canvas to index.html and give it a width and height attribute. Apply 
// some styling to give it a border and center it on the page. 

// Get the canvas object
var canvas = document.querySelector("#main-canvas");

// Create a drawing context - defines whether we will be drawing in 2D or 3D 
var ctx = canvas.getContext("2d");

// Drawing a solid rectangle
// 	- Set the current style
// 	- Draw the rectangle with the current style
// 		- What's the coordinate system?
ctx.fillStyle = "rgb(255,0,255)";
ctx.fillRect(200, 100, 400, 400);

// Drawing a rectangle outline
ctx.strokeStyle = "rgb(0,0,0)";
ctx.lineWidth = 20;
ctx.strokeRect(300, 200, 200, 200);

// Adding an event to draw a random rectangle
function drawRandomRect() {
	var x = randInt(0, 800);
	var y = randInt(0, 600);
	var l = randInt(25, 75);
	ctx.fillStyle = "hsl(305, 50%," + l + "%)";
	ctx.fillRect(x, y, 50, 50);
}

canvas.addEventListener("mousemove", drawRandomRect);