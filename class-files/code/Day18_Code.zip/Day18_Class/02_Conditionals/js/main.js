/*
	Making Decisions a.k.a. Conditionals
*/

var score = prompt("What's the score?");
score = Number(score);

console.log(score >= 50); // Returns either true or false

if (score >= 90) {
	console.log("A 🎉🎉🎉🎉🎉🎉");	
} else if (score >= 80) {
	console.log("B");
} else if (score >= 70) {
	console.log("C");
} else if (score >= 60) {
	console.log("D");
} else {
	console.log("F 😝");
}

// Boolean variables
var isRaining = true;
if (isRaining) {
	console.log("Don't forget to bring your umbrella.")
}

var hasPassedTest = (score >= 50);

// Create a function that takes a number and returns a string with
// the corresponding letter grade. Use this grade scale:
// 		A = 90 to 100
// 		B = 80 up to (but not including) 90
// 		C = 70 up to (but not including) 80
// 		D = 60 up to (but not including) 70
// 		F = Anything below a 60