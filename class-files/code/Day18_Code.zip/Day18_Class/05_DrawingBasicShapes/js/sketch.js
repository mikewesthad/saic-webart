/*
	Let's create some shapes with p5. Ellipses, rectangles, lines, oh my.

	New p5 variables and functions:
		setup(), draw()
		createCanvas()
		windowWidth, windowHeight
		background(...)
		fill(...), noFill(...)
		stroke(...), noStroke(...), strokeWeight(...)
		ellipse(...), rect(...)
*/ 

// Check out index.html first

// Setup runs ONCE at the start of the sketch
function setup() {
	createCanvas(windowWidth, windowHeight);
}

// After setup is run, draw runs continuously at 60 fps
function draw() {
	// Draw a black background
	background(0, 0, 0);

	// Set the style for drawing
	fill(255, 255, 255);
	stroke(255, 200, 0);
	strokeWeight(10);

	ellipse(200, 100, 100, 100);
	rect(150, 150, 100, 200);

	// Change the style for drawing
	fill(255, 0, 255);
	noStroke();

	ellipse(400, 100, 100, 100);
	rect(350, 150, 100, 200);

	// Change the style for drawing (again)
	noFill();
	stroke(255, 0, 255);

	ellipse(600, 100, 100, 100);
	rect(550, 150, 100, 200);

	strokeWeight(20);
	stroke(0,255,255);
	line(0, 0, 800, 600);
}