/*
	Interactivity - using the mouse!

	New p5 variables and functions:
		mouseIsPressed
		mouseButton
		mouseX, mouseY
*/ 


// Setup runs ONCE at the start of the sketch
function setup() {
	createCanvas(windowWidth, windowHeight);
	background(0);
}

// After setup is run, draw runs continuously at 60 fps
function draw() {
	console.log(mouseIsPressed);

	background(0, 10); // Motion trail effect

	if (mouseIsPressed) {
		if (mouseButton === LEFT) {
			// Drawing a "glowing" brush
			fill(255, 0, 255, 3);
			noStroke();
			for (var radius = 20; radius <= 300; radius += 20) {
				ellipse(mouseX, mouseY, radius, radius);
			}

		} else if (mouseButton === RIGHT) {
			// Erasing the screen
			background(0);
		}
	}
}
