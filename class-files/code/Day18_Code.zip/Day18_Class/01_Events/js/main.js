/*
                  FUNCTIONS + EVENTS = INTERACTIVITY

	      ᕙ༼ ,,ԾܫԾ,, ༽ᕗ      ᕙ༼ ,,ԾܫԾ,, ༽ᕗ      ᕙ༼ ,,ԾܫԾ,, ༽ᕗ

	Now that we understand functions...we can start making our sites 
	interactive.  Gone are the days of relying on prompts and alerts! 
	(Well, almost...)

	We are going to be creating some buttons that change properties of the page.
*/


// -- SIZE CHANGE -------------------------------------------------------------

// We are going to create a button that can change it's own font size.

// Global variables! Get any DOM elements we will need.
var sizeButton = document.querySelector("#size-button");

// Define a function that will change the button's font size
function changeSize() {
	var newSize = randNum(10, 100);
	sizeButton.style.fontSize = newSize + "px";
}

// "Bind" the function to the click event of the button. This lets the button
// know what to do whenever it is clicked
sizeButton.addEventListener("click", changeSize);

// What happens if we add a transition to the button?
sizeButton.style.transition = "font-size 0.2s ease";


// -- CLICK CLICK --------------------------------------------------------------

// See the click counter div in the HTML?  We want to display the current number
// times the #click-button has been clicked in that div.
 
// Create a global variable to hold the number of clicks
var numClicks = 0;

// Create a global variable with a reference to the click counter div
var clickButton = document.querySelector("#click-button");
var clickCounter = document.querySelector("#click-counter");

// Define a countClicks function that increments the numClicks variable and 
// updates the click counter div
function countClicks() {
	numClicks += 1;
	clickCounter.textContent = "Clicks: " + numClicks;
}

// Bind the countClicks function to the button's onclick event
clickButton.addEventListener("click", countClicks);


// -- COLOR CHANGING CLICKS ----------------------------------------------------

// Create some code that incrementally changes the background color of body
// (e.g. the color could start black and every click could make it more red).
// You'll want a global variable (e.g. redValue) that will allow you to keep
// track of some aspect of the current background color (e.g. the red channel
// of the rgb color).

var colorButton = document.querySelector("#color-button");
var redValue = 0;
var hueValue = 0;

document.body.style.transition = "background-color 0.2s ease";

function incrementBackground() {
	// redValue += 50;
	// document.body.style.backgroundColor = "rgb(" + redValue + ", 0, 0)";
	
	hueValue += 20;
	document.body.style.backgroundColor = "hsl(" + hueValue + ", 50%, 50%)";
}

colorButton.addEventListener("click", incrementBackground);


// -- PAIRS OF EVENTS ----------------------------------------------------------

// Some events make sense to handle in pairs (or triples), e.g. mouseover & 
// mouseout

var growDiv = document.querySelector("#grow-div");
growDiv.style.transition = "all 0.2s ease";
var originalText = growDiv.textContent;

function hulkOut() {
	growDiv.style.fontSize = "120px";
	growDiv.textContent = "ANGRY";
	growDiv.style.color = "crimson";
	growDiv.style.letterSpacing = "40px";
}

function reset() {
	growDiv.style.fontSize = "";
	growDiv.textContent = originalText;
	growDiv.style.color = "";
	growDiv.style.letterSpacing = "";
}

growDiv.addEventListener("mouseover", hulkOut);
growDiv.addEventListener("mouseout", reset);


