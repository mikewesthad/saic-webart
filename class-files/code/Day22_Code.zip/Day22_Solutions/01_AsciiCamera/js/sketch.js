/*
	We can get the web camera through p5.js. It's actually a video element under
	the hood, so include p5.dom.min.js!

	Again, the tutorial on video in p5 is a good reference: 
		http://creative-coding.decontextualize.com/video/
*/

var capture;
var characterMap = " .,:;ox%#@T";
// var characterMap = ["👐🏾", "💜", "😱", "💛", "👠", "😍", "😡"]; // http://getemoji.com/
var font;

function preload() {
	font = loadFont("fonts/AlfaSlabOne-Regular.ttf");
}

function setup() {
	createCanvas(640, 480);

	capture = createCapture(VIDEO);
	capture.hide();
	
	pixelDensity(1);

	textFont(font); // Don't use a font if you want emoji support!
	textSize(10);
}

function draw() {
	capture.loadPixels();
	if (capture.pixels.length === 0) return;

	background(0);
	
	var sampleSize = 10; 	
	for (var py = 0; py < capture.height; py += sampleSize) {
		for (var px = 0; px < capture.width; px += sampleSize) {

			var i = 4 * (py * capture.width + px);
			var r = capture.pixels[i];
			var g = capture.pixels[i + 1];
			var b = capture.pixels[i + 2];
			var a = capture.pixels[i + 4];

			// Convert RGB to grayscale
			var gray = 0.2989 * r + 0.5870 * g + 0.1140 * b;
			
			fill(r, g, b);
			noStroke();
			
			// Conditional approach to mapping grayscale to text
			// if (gray < 127) {
			// 	text("o", px, py);
			// } else {
			// 	text("O", px, py);
			// }

			// Advanced approach to mapping grayscale to a character from an
			// array or string
			var charIndex = floor((gray / 256) * characterMap.length);
			text(characterMap[charIndex], px, py);
		}
	}
}