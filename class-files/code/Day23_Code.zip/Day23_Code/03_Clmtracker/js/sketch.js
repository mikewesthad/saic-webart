/*
	Face Tracking
	
	clmtrackr:
		https://github.com/auduno/clmtrackr
	More computer vision examples:
		https://kylemcdonald.github.io/cv-examples/
*/ 

var capture;
var ctracker;
var positions;

function setup() {
	createCanvas(640, 480);

	capture = createCapture(VIDEO);
	capture.hide();

	// Start the tracker
	ctracker = new clm.tracker();
	ctracker.init(pModel); // Comes from the model js file
	// Only start the tracker when the capture has loaded the first frame
	capture.elt.addEventListener("loadeddata", startTracker);
}

function startTracker() {
	ctracker.start(capture.elt);
}

function draw() {
	background(0);
	// image(capture, 0, 0);

	positions = ctracker.getCurrentPosition();
	if (positions === false) {
		// Stop if we haven't detected a face
		return;
	}

	// Draw the score to the screen
	fill(255);
	noStroke();
	textSize(20);
	var score = ctracker.getScore();
	text("Face score: " + score, 10, 25);

	// Draw ellipses at the positions
	drawFacePoints();

	// Draw emojis at eyes and mouth
	drawEmojiFace();

	// Connect vertices within a shape
	drawShapes();

}

function drawShapes() {
	// Left eye
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([23, 66, 26, 65, 25, 64, 24, 63]);

	// Right eye
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([30, 69, 31, 70, 28, 67, 29, 68]);

	// Top lip
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([44, 45, 46, 47, 48, 49, 50, 59, 60, 61]);
	
	// Bottom lip
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([44, 56, 57, 58, 50, 51, 52, 53, 54, 55]);
}

function drawEmojiFace() {
	fill(255);
	noStroke();
	textSize(50);
	textAlign(CENTER, CENTER);
	text("💲", positions[27][0], positions[27][1]);
	text("💲", positions[32][0], positions[32][1]);
	textSize(100);
	text("👄", positions[57][0], positions[57][1]);
}

function drawFacePoints() {
	fill(255);
	stroke(0);
	strokeWeight(1);
	for (var i = 0; i < positions.length; i++) {
		var point = positions[i];
		var x = point[0];
		var y = point[1];
		ellipse(x, y, 4, 4);
	}
}

function drawFaceShape(indices) {
	beginShape();
	for (var i = 0; i < indices.length; i++) {
		var positionIndex = indices[i];
		var point = positions[positionIndex];
		vertex(point[0], point[1]);
	}
	endShape();
}