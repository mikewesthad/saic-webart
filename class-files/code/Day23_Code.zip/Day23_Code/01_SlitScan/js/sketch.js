/*
	Slit-Scan Camera

	List of slit-scan works: http://www.flong.com/texts/lists/slit_scan/
	p5 copy reference: http://p5js.org/reference/#/p5/copy
*/ 

var button;
var capture;
var dx = 0;

function setup() {
	createCanvas(620, 480);

	capture = createCapture(VIDEO);
	capture.hide();

	pixelDensity(1); // Hack for high DPI screens

	// In class question: how can we save the canvas? Create a button!
	button = createButton("Save");
	button.position(640, 20);
	button.mousePressed(saveScreenshot);
}

function saveScreenshot() {
	save("screenshot.png");
}

function draw() {
	capture.loadPixels();
	if (capture.pixels.length === 0) {
		// Stop running the draw function if we don't have pixels yet
		return;
	}

	var middlePixel = floor(capture.width / 2);
	var sliceWidth = 1;

	copy(
		capture, // Source
		middlePixel, 0, sliceWidth, capture.height, // sx, sy, sw, sh
		dx, 0, sliceWidth, capture.height // dx, dy, dw, dh
	);

	dx += sliceWidth;

	if (dx > capture.width) {
		dx = 0;
	}
}
