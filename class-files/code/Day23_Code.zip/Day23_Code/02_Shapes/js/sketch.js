/*
	Custom Shapes!

	Shapes reference:
		http://p5js.org/reference/#group-Shape
	Objects tutorial:
		https://www.youtube.com/watch?v=-e5h4IGKZRY	
*/ 

var xPositions = [];
var yPositions = [];

var points = [];

function setup() {
	createCanvas(windowWidth, windowHeight);

	var point = {
		x: 200, // similar to saying x = 200
		y: 300,
		r: 255,
		g: 0,
		b: 0,
		a: 255
	};
	console.log(point.y);

}

function draw() {
	background(255);

	fill(255, 0, 255);
	stroke(0);
	strokeWeight(20);
	strokeJoin(ROUND);

	// beginShape();
	// vertex(100, 100);
	// vertex(400, 100);
	// vertex(600, 200);
	// vertex(400, 400);
	// vertex(100, 400);
	// endShape(CLOSE); // CLOSE will connect the first and last vertex
	
	// beginShape(TRIANGLE_STRIP);
	// for (var i = 0; i < xPositions.length; i++) {
	// 	vertex(xPositions[i], yPositions[i]);
	// }
	// endShape();
	
	beginShape(TRIANGLE_STRIP);
	for (var i = 0; i < points.length; i++) {
		var point = points[i];
		fill(point.r, point.g, point.b, point.a);
		stroke(point.r, point.g, point.b, point.a);
		vertex(point.x, point.y);
	}
	endShape();
}

function mousePressed() {
	// Simple approach to storing information - separate array for each piece of
	// data we want to store
	xPositions.push(mouseX);
	yPositions.push(mouseY);

	// Better approach to storing complex information - objects allow us to 
	// store multiple pieces of data together inside of a single container
	var point = {
		x: mouseX,
		y: mouseY,
		r: 255,
		g: 0,
		b: map(frameCount, 0, 600, 0, 255),
		a: 255
	};
	points.push(point);
}