/*
	DOM Warmup
*/

// Get the food list and change it's background color
var foodList = document.querySelector("#food-list");
foodList.style.backgroundColor = "deepskyblue";

// Add a sixth item to the end of the food list
var listItem = document.createElement("li");
listItem.textContent = "Strawberries";
foodList.appendChild(listItem);

// Get all the items in the food list, loop over them and give each a color and 
// a font size
var items = document.querySelectorAll("#food-list li");
for (var i = 0; i < items.length; i++) {
	items[i].style.color = "white";
	items[i].style.fontSize = "24px";
}

// Get all the out-of-stock food list items and add add a "line-through" 
// text-decoration to them.
var oosItems = document.querySelectorAll("#food-list .out-of-stock");
for (var i = 0; i < oosItems.length; i++) {
	oosItems[i].style.textDecoration = "line-through";
}