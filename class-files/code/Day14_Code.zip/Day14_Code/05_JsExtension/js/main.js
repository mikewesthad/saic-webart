// Test that it's working:
console.log("Random number:" + randInt(0, 10));

// Create an array of URLs to Trump images on the net. Note: these need to be
// https links.
var trumps = [
	"https://cdn.theatlantic.com/assets/media/img/2016/05/select_32/hero_wide_640.jpg?1463509000",
	"https://static4.businessinsider.com/image/56c640526e97c625048b822a-480/donald-trump.jpg",
	"https://static3.businessinsider.com/image/56feb17752bcd01b008ba4e8-480/donald-trump.jpg",
	"https://static2.businessinsider.com/image/57431cad52bcd026008c4814-480/donald-trump.jpg",
	"https://i.imgur.com/Pa0IOhB.jpg",
	"https://thenypost.files.wordpress.com/2016/10/trump-smile.jpg?quality=90&strip=all&w=664&h=441&crop=1"
];

// Get all the images using querySelectorAll
var images = document.querySelectorAll("img");

// Loop over the images and replace the src with a random trump image. You'll 
// want to use object-fit cover styling as well.
for (var i = 0; i < images.length; i++) {
	var randTrumpIndex = randInt(0, trumps.length - 1);
	var randTrumpUrl = trumps[randTrumpIndex];
	images[i].src = randTrumpUrl;
	images[i].objectFit = "cover";
}

// More! Loop over all the divs and give them a Trump background image.
var divs = document.querySelectorAll("div");
for (var i = 0; i < divs.length; i++) {
	var randIndex = randInt(0, trumps.length - 1);
	var randUrl = trumps[randIndex];
	divs[i].style.background = "url('" + randUrl + "') 50% 50% / cover";
}