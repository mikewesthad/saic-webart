/*
	Making Decisions a.k.a. Conditionals
*/

// Simple if statement

// If...else statement 

// If...else if...else statement

// Boolean variables

// Create a function that takes a number and returns a string with
// the corresponding letter grade. Use this grade scale:
// 		A = 90 to 100
// 		B = 80 up to (but not including) 90
// 		C = 70 up to (but not including) 80
// 		D = 60 up to (but not including) 70
// 		F = Anything below a 60