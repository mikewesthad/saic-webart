/*
	HIPSTER MIX-AND-MATCH

	We're going to create a hipster face in which we can click to mix &	match 
	the different components of the hipster face: glasses, mustache or bowtie.

	Check out index.html.  The page is super simple - just three images in a 
	wrapper.  Check out the "images/" folder.  I've given you 6 of each type of 
	image: bowties, glasses and mustaches.

	The goal is that when someone clicks on a component of the face 
	(e.g. bowtie) that the img element cycles through the 6 images for that 
	component (e.g. bowtie1 -> bowtie2 -> bowtie3 -> ...).

			    (-(-_(-_-)_-)-)   (-(-_(-_-)_-)-)   (-(-_(-_-)_-)-)
*/

// Get a reference to the img elements


// Make the glasses interactive. On every click, we want to load the next
// glasses image in the sequence (e.g. the src changes from glasses1.gif to
// glasses2.gif).
// Tips:      
// 	- We'll need a global variable
// 	- We'll need a conditional....


// Do the same for the mustache


// Do the same for the bowtie
