/*
	FIRST CLASS FUNCTIONS

	Functions in JavaScript are like other variables.  They can be assigned to 
	variables.  They can passed as an argument to another function.  A function 
	can even return a function...
*/


// Define a welcomeUser function that displays an alert with a general welcome
// message
function welcomeUser() {
	var message = "Welcome to the spooky site!";
	alert(message);
}

// Call the function.  Using parentheses after a function name calls/invokes
// that function, e.g. it executes the code associated with the function
welcomeUser();

// If we leave off the parentheses, the function isn't invoked.  In fact it acts
// like a variable!
console.log("welcomeUser is: " + welcomeUser);

// Define a variable called aliasFunction that is equal to welcomeUser
var aliasFunction = welcomeUser;
aliasFunction();