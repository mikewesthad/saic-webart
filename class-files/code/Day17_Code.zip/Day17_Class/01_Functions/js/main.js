/*
                              FUNCTIONS!

	(/.__.)/  \(.__.\)    (/.__.)/  \(.__.\)    (/.__.)/  \(.__.\)

	We are going to make our very first functions.  Functions allow us to write
	more flexible and reusable code.  

	You may see functions brought up in the context of an acronym, DRY:
		DRY = Don't repeat youself
*/


// -- FIRST FUNCTION -----------------------------------------------------------

// Define a simple function that prints a greeting to the console
function printHello() {
	console.log("Hi there!");
	console.log("This is our first function 🎉🎉🎉🎉🎉🎉");
}

// Invoke/call the function to run it
printHello();


// -- WELCOME FUNCTION ---------------------------------------------------------

// Define our first function, welcomeUser(), that adds a weclome message to the
// body of our page.
function welcomeUser(username) {
	var h1 = document.createElement("h1");
	h1.textContent = "Happy halloween, " + username;
	var outputDiv = document.querySelector("#output");
	outputDiv.appendChild(h1);
}

// Variables defined inside of a function live inside of the function. We cannot
// access them from outside of the function.
// console.log(h1); <- Danger: error!

// Call welcomeUser()
welcomeUser("Mike");

// Call welcomeUser() a few more times
welcomeUser("Tongxin");
welcomeUser("Caleb");

// What happens if we forget to put in an argument?
welcomeUser();

// Modify welcomeSpecificUser(...) function in some way
// 	Notice how we only had to make a change in one place and the change applies
//  every time we use the function?


// -- HEADER FUNCTION ----------------------------------------------------------

// We could improve upon our previous function. It's common for us to create a
// header that has a particular class and has some text content. Let's create a
// function that does that.
function addHeader(stringClasses, text) {
	var h1 = document.createElement("h1");
	h1.textContent = text;
	h1.className = stringClasses;
	var outputDiv = document.querySelector("#output");
	outputDiv.appendChild(h1);
}

// We've got a few classes in the CSS for this project (.warning and 
// .fadeTransition). Let's apply them to some headers:
addHeader("warning", "Error! Error!");
addHeader("fadeTransition", "I am animated. Hover me!");
addHeader("warning fadeTransition", "I have both classes");
addHeader("", "I have no class.")

// -- AVERAGING FUNCTION -------------------------------------------------------

// Define a new function that calculates the average of three numbers, 
// getAverage(...), and returns the result.
function getAverage(num1, num2, num3) {
	var sum = num1 + num2 + num3;
	var average = sum / 3;
	return average;
}

// Get the average of 10, 20 and 30 and put the result on the page using 
// addHeader(...)
var average1 = getAverage(10, 20, 30);
addHeader("calculator", "The average is: " + average1);

// Get the average of 60, 20 and 100 and print it
var average2 = getAverage(60, 20, 100);
addHeader("calculator", "The average is: " + average2);

// See how writing code in modular pieces can help prevent us from repeating 
// ourselves?


// -- CREATING ELEMENTS --------------------------------------------------------

// Let's create a addElement(...) function that can be used to create any 
// type of element and add it to the page. It should allow us to specify:
//  - Tag name
//  - Any classes we want to apply
//  - Any text we want to put in the element
//  - A parent element
function addElement(tagName, stringClasses, text, parentElement) {
	var element = document.createElement(tagName);
	element.className = stringClasses;
	element.textContent = text;
	parentElement.appendChild(element);
	return element;
}

// Add a list to the #recipe-container
var container = document.querySelector("#recipe-container");
var list = addElement("ol", "", "", container);
var item1 = addElement("li", "", "Plantains", list);
item1.style.textDecoration = "underline";
var item2 = addElement("li", "", "Avocado", list);
var item3 = addElement("li", "", "Broccoli", list)



// -- PRACTICE -----------------------------------------------------------------

// getLifeInSeconds(...)
// Define a new function that takes 1 parameter (ageInYears) and returns the
// number of seconds someone has been alive (Ignore leap years.)
// Use the function to check how old you are in seconds.

function getLifeInSeconds(ageInYears) {
	return ageInYears * 365 * 24 * 60 * 60;
}

var message = "Your life is " + getLifeInSeconds(28) + 
	" seconds long and counting.";
addElement("h1", "", message, document.body);


// convertFahrenheitToCelsius(...)
// Define a function that takes 1 parameter (degreesFahrenheit) and returns the 
// temperature in celsius. The conversion formula is: C = (F - 32) * 5 / 9
// Use the function to check what 32F and 100F are in celsius.

function convertFahrenheitToCelsius(degreesFahrenheit) {
	var degreesCelsius = (degreesFahrenheit - 32) * 5 / 9;
	return degreesCelsius;
}

var message1 = "32F is: " + convertFahrenheitToCelsius(32) + "C";
addElement("h1", "", message1, document.body);
var message2 = "100F is: " + convertFahrenheitToCelsius(100) + "C";
addElement("h1", "", message2, document.body);


// randInArray(...) 
// Below is the randInt(...) function. It takes two parameters, a min and a max,
// and returns a random integer between two values. Using randInt(...), write a
// function that returns a randomly choosen element from a given array. The
// function should have 1 parameter (the array).
// Use the function to pick a random element from clintonSentences, or from an
// array of your own making.

function randInt(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randInArray(array) {
	var randomIndex = randInt(0, array.length - 1);
	var randomElement = array[randomIndex];
	return randomElement;
}

var randQuote = randInArray(clintonSentences);
addElement("h1", "quote", randQuote, document.body);

var fonts = ["Inconsolata", "Oswald", "Indie Flower", "Merriweather", "VT323"];
var randFontHeader = addElement("h1", "", "Random Font!", document.body);
randFontHeader.style.fontFamily = randInArray(fonts);


// createOrderedList(...)
// Create a function that creates an ordered list and adds it to the page. It 
// should take 2 parameters:
// 	- an array of list items (the text that should be inside each li)
// 	- a parent element (the element that the ol should be added to)
// Use the function to add a list of pokemon to the #pokemon-container element.

function createOrderedList(listItems, parentElement) {
	var ol = addElement("ol", "", "", parentElement);
	for (var i = 0; i < listItems.length; i++) {
		addElement("li", "", listItems[i], ol);
	}
	return ol;
}

var parentElement = document.querySelector("#pokemon-container");
var items = ["Bulbasaur", "Pikachu", "Abra"];
createOrderedList(items, parentElement);
