/*
	p5.dom

	The p5.dom library allows us to create and interact with other HTML elements
	more easily than raw JS. In order to use it you need to uncomment the 
	"p5.dom.min.js" script in index.html.

	The p5.dom reference page is here: 
		https://p5js.org/reference/#/libraries/p5.dom

	Tutorial:
		https://github.com/processing/p5.js/wiki/Beyond-the-canvas

	Create a slider for the background color: 
		- hue
		- saturation
		- brightness
*/ 

var hSlider;
var sSlider;
var bSlider;

function setup() {
	createCanvas(600, 600);

	colorMode(HSB, 360, 100, 100, 1);

	// Hue slider
	hSlider = createSlider(0, 360, 0);
	hSlider.position(620, 20);
	hSlider.size(300, 50);

	// Saturation slider
	sSlider = createSlider(0, 100, 70);
	sSlider.position(620, 80);
	sSlider.size(300, 50);

	// Brightness slider
	// 	This one is a vertical slider
	bSlider = createSlider(0, 100, 70);
	makeSliderVertical(bSlider);
	bSlider.position(620, 140);
	bSlider.size(50, 400);
}

function draw() {
	var h = hSlider.value();
	var s = sSlider.value();
	var b = bSlider.value();
	background(h, s, b, 0.2);
}

function makeSliderVertical(slider) {
	slider.style("-webkit-appearance", "slider-vertical"); // Chrome & Safari
	slider.style("writing-mode", "bt-lr"); // IE
	slider.attribute("orient", "vertical"); // Firefox
}
