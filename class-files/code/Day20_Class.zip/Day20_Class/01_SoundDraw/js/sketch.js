/*
	Music drawing
	
	Combining what we've learned. Create a musical drawing sketch:

	1. When the user presses the left mouse button, an ellipse should be drawn
	   to the page.
	2. Load a sound. Use the amplitude (volume) of the sound to change some
	   aspect of the drawing using map(...). E.g. you could change the color 
	   and/or the size of the ellipse.
	3. Instead of drawing an ellipse when the user clicks, draw an image. A png
	   with a transparent background will look best.
	4. Rotate the image around the mouse like how we did in 03_Rotation.

	Since this sketch loads sounds, you need to enable the p5 sound library in
	index.html. Also, anytime we load files, we need to view the site through a 
	local server.
*/ 

var musicTrack; 
var amplitude;
var img;
var rotation = 0;

function preload() {
	img = loadImage("images/brush.png");
	musicTrack = loadSound("audio/baths-animals.mp3");
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	musicTrack.play(); // Start the music playing
	background(0); // Initialize the screen with a coat of black
	amplitude = new p5.Amplitude();

	// We can skip ahead in a track to a specific timestamp (in seconds)
	musicTrack.jump(30);
}

function draw() {

	if (mouseIsPressed && mouseButton === LEFT) {

		// Get the volume of the track.
		var level = amplitude.getLevel(); // Between 0 and 1
		var c = map(level, 0, 1, 10, 200);
		var radius = map(level, 0, 1, 10, 400);	

		// Ellipse version
		// fill(c, 0, c, 200);
		// noStroke();
		// ellipse(mouseX, mouseY, radius, radius);

		// Image version
		rotation += 100;
		push();
			tint(255, 0, random(0, 255), 50);
			translate(mouseX, mouseY);
			rotate(rotation);
			imageMode(CENTER);
			image(img, 0, 0, radius, radius);
		pop();
	}
}

