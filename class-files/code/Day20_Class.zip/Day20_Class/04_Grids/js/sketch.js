/*
	Grids! 

	Nested loops aren't so scary. We are going to create a grid of colors. To 
	create a grid, we need something that looks like this (in pseudocode):

		for (y positions that are evenly spaced along the screen)
			for (x positions that are evenly spaced along the screen)
				draw a rectangle/circle/etc. at (x, y)

	New p5 variables and functions:
		colorMode(...)
*/ 

function setup() {
	createCanvas(windowWidth, windowHeight);
	colorMode(HSB, 360, 100, 100, 1);
}

function draw() {
	background(0);

	var stepSize = 50;
	for (var y = 0; y < height; y += stepSize) {
		for (var x = 0; x < width; x += stepSize) {

			var distance = dist(x, y, mouseX, mouseY);
			distance = constrain(distance, 0, 600);
			var size = map(distance, 0, 600, 80, 5);

			var hue = map(x, 0, width, 0, 360);

			fill(hue, 50, 100);
			noStroke();
			ellipse(x, y, size, size);

		}
	}
}