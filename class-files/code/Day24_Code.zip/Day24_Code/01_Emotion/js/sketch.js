/*
	Face Tracking
	
	clmtrackr:
		https://github.com/auduno/clmtrackr
	More computer vision examples:
		https://kylemcdonald.github.io/cv-examples/
*/ 

var capture;
var ctracker;
var positions;
var classifier;

function setup() {
	createCanvas(640, 480);

	capture = createCapture(VIDEO);
	capture.hide();

	// Start the tracker
	ctracker = new clm.tracker();
	ctracker.init(pModel); // Comes from the model js file
	// Only start the tracker when the capture has loaded the first frame
	capture.elt.addEventListener("loadeddata", startTracker);

	// Start the emotion classifier
	classifier = new emotionClassifier();
	classifier.init(emotionModel); // Comes from the emotionmodel.js

	background(0);
}

function startTracker() {
	ctracker.start(capture.elt);
}

function draw() {
	background(0);

	// Get tracker and emotion data
	positions = ctracker.getCurrentPosition();
	var parameters = ctracker.getCurrentParameters();
	var emotionData = classifier.meanPredict(parameters);
	if ((positions === false) || (emotionData === false)) {
		// Stop if we haven't detected a face or we don't have emotion data yet
		return;
	}

	// Loop over the emotionData to find the strongest emotion
	var dominantEmotion = "";
	var dominantEmotionValue = 0;
	for (var i = 0; i < emotionData.length; i++) {
		var emotionName = emotionData[i].emotion;
		var emotionValue = emotionData[i].value;
		if (emotionValue > dominantEmotionValue) {
			// We have found a new dominant emotion
			dominantEmotion = emotionName;
			dominantEmotionValue = emotionValue;
		}
	}

	// The order in which we draw things matters, first fill the canvas with our
	// tinted webcam frame
	capture.loadPixels(); // p5 bug fix
	if (dominantEmotion === "angry") {
		tint(255, 0, 0);
	} else if (dominantEmotion === "happy") {
		tint(255, 255, 0);
	} else if (dominantEmotion === "sad") {
		tint(0, 0, 255);
	} else {
		noTint();
	}
	image(capture, 0, 0);

	// Draw ellipses at the points in the face model
	drawFacePoints();

	// Draw the score to the screen
	fill(255);
	noStroke();
	textSize(20);
	textAlign(LEFT, BASELINE);
	var score = ctracker.getScore();
	text("Face score: " + nfc(score, 2), 10, 25);

	// Draw the emotion values to the screen
	for (var i = 0; i < emotionData.length; i++) {
		var emotionName = emotionData[i].emotion;
		var emotionValue = emotionData[i].value;
		var y = 80 + (i * 30);
		text(emotionName + ": " + nfc(emotionValue, 2), 10, y);
	}

}

function drawShapes() {
	// Left eye
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([23, 66, 26, 65, 25, 64, 24, 63]);

	// Right eye
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([30, 69, 31, 70, 28, 67, 29, 68]);

	// Top lip
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([44, 45, 46, 47, 48, 49, 50, 59, 60, 61]);
	
	// Bottom lip
	fill(255, 0, 0);
	noStroke();
	drawFaceShape([44, 56, 57, 58, 50, 51, 52, 53, 54, 55]);
}

function drawFaceShape(indices) {
	beginShape();
	for (var i = 0; i < indices.length; i++) {
		var positionIndex = indices[i];
		var point = positions[positionIndex];
		vertex(point[0], point[1]);
	}
	endShape();
}

function drawEmojiFace() {
	fill(255);
	noStroke();
	textSize(50);
	textAlign(CENTER, CENTER);
	text("💲", positions[27][0], positions[27][1]);
	text("💲", positions[32][0], positions[32][1]);
	textSize(100);
	text("👄", positions[57][0], positions[57][1]);
}

function drawFacePoints() {
	fill(255);
	stroke(0);
	strokeWeight(1);
	for (var i = 0; i < positions.length; i++) {
		var point = positions[i];
		var x = point[0];
		var y = point[1];
		ellipse(x, y, 4, 4);
	}
}