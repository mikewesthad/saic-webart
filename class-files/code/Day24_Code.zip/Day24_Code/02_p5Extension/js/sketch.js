/*
	p5.js + Extensions
*/

var cursorImage;
var cursors = [];

function preload() {
	var imageUrl = chrome.extension.getURL("images/windows-cursor.png");
	cursorImage = loadImage(imageUrl);
}

function setup() {
	var canvas = createCanvas(windowWidth, windowHeight);

	// Position the canvas as fixed and on top of everything else on the screen
	canvas.elt.style.position = "fixed"; // <- p5 bug
	canvas.style("top", "0px");
	canvas.style("left", "0px");
	canvas.style("z-index", 999999999);
	canvas.style("pointer-events", "none");

	// "Defensive" styling of our canvas
	canvas.style("background", "transparent");
	canvas.style("margin", "0px");
	canvas.style("padding", "0px");

	// We hid the cursor with css/main.css
	
	cursorImage.resize(20, 0);

	colorMode(HSB, 360, 100, 100, 1);

	// Fill the array with fake cursors
	// for (var i = 0; i < 1000; i++) {
	// 	var cursor = {
	// 		xOffset: random(-width, width),
	// 		yOffset: random(-height, height),
	// 		color: color(random(0, 360), 100, 100)
	// 	};
	// 	cursors.push(cursor);
	// }
	
	// Add a fake cursor every 1s - setInterval allows us to schedule a function
	// to run ever X milliseconds
	setInterval(addCursor, 1000); // 1000ms === 1s
}

function draw() {
	// clear allows us to reset the canvas back to completely transparent
	// clear();

	// Draw an ellipse
	// fill(255, 0, 255);
	// stroke(255);
	// strokeWeight(1);
	// ellipse(mouseX, mouseY, 20, 20);
	
	// Draw the original cursor
	noTint();
	image(cursorImage, mouseX, mouseY);
	
	// Draw all the "fake" cursors
	for (var i = 0; i < cursors.length; i++) {
		var cursor = cursors[i];
		tint(cursor.color);
		image(cursorImage, mouseX + cursor.xOffset, mouseY + cursor.yOffset);
	}
}

function addCursor() {
	var cursor = {
		xOffset: random(-width/2, width/2),
		yOffset: random(-height/2, height/2),
		color: color(random(0, 360), 100, 100)
	};
	cursors.push(cursor);	
}