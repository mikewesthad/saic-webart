/*
	Face Tracking - modified to use the nose as a marker for drawing
	
	clmtrackr:
		https://github.com/auduno/clmtrackr
	More computer vision examples:
		https://kylemcdonald.github.io/cv-examples/
*/ 

var capture;
var ctracker;
var positions;

function setup() {
	createCanvas(640, 480);

	capture = createCapture(VIDEO);
	capture.hide();

	// Start the tracker
	ctracker = new clm.tracker();
	ctracker.init(pModel); // Comes from the model js file
	// Only start the tracker when the capture has loaded the first frame
	capture.elt.addEventListener("loadeddata", startTracker);

	background(0);
}

function startTracker() {
	ctracker.start(capture.elt);
}

function draw() {
	// background(0);
	// image(capture, 0, 0);

	positions = ctracker.getCurrentPosition();
	if (positions === false) {
		// Stop if we haven't detected a face
		return;
	}

	// Using the nose as a marker for a drawing app
	background(0, 10); // Clear the screen with some transparency
	fill(0);
	stroke(255);
	// Find the distance between the left and right sides of the nose
	var d = dist(
		positions[35][0], positions[35][1],
		positions[39][0], positions[39][1]
	);
	// Draw the "marker"
	ellipse(positions[62][0], positions[62][1], d, d);
}